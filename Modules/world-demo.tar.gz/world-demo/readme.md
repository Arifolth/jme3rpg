World Demo
===

A tech demo utilizing various libraries created by myself for [jMonkeyEngine](https://jmonkeyengine.org):

- FastNoise
- world-pager
- position-plotters

This demo generates and displays an "infinite" world with terrain, grass, flowers, ocean and trees.
A GUI is provided to toy with the various settings.

![Preview Image](https://i.ibb.co/DgvC7by/image.png)