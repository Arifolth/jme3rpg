package mygame;

import com.jme3.font.BitmapFont;
import com.jme3.font.BitmapText;
import com.jme3.app.SimpleApplication;
import com.jme3.asset.AssetManager;
import com.jme3.bullet.BulletAppState;
import com.jme3.math.ColorRGBA;
import com.jme3.math.Vector3f;
import com.jme3.niftygui.NiftyJmeDisplay;
import com.jme3.renderer.Camera;
import com.jme3.scene.Node;
import com.jme3.shadow.PssmShadowRenderer;
import com.jme3.system.AppSettings;
import de.lessvoid.nifty.Nifty;
import de.lessvoid.nifty.elements.Element;
import de.lessvoid.nifty.elements.render.TextRenderer;
import de.lessvoid.nifty.screen.Screen;
import de.lessvoid.nifty.screen.ScreenController;

/**
 * test
 * @author normenhansen
 */
public class Main extends SimpleApplication  {

    private static BitmapText sysout;//debug to player screen
    private static Main instance = null;
    private boolean running;

    

    public AssetManager getAM() {return assetManager; }
    public Camera getCam() { return cam; }
    public Node getRN() { return rootNode; }

    public static Main get() {
        if (instance == null) {
            instance = new Main();
        }
        return instance;
    }

    private Main() {
    }

    public static void main(String[] args) {
        Main app = Main.get();

        AppSettings settings = new AppSettings(true);
        settings.setResolution(1280, 720);
        settings.setRenderer(AppSettings.LWJGL_OPENGL2);
        app.setSettings(settings);

        app.start();
    }

    @Override
    public void simpleInitApp() {

        //setup shadows
        PssmShadowRenderer pssmRenderer = new PssmShadowRenderer(assetManager, 1024, 4);
        pssmRenderer.setDirection(new Vector3f(-1, -1, -1).normalizeLocal());
        viewPort.addProcessor(pssmRenderer);

        //set background/sky color
        viewPort.setBackgroundColor(new ColorRGBA(0.53f, 0.81f, 0.98f, 1f));

        //set camera rotation speed
        flyCam.setMoveSpeed(100);
        //flyCam.setEnabled(false);

        //set clipping distance
        cam.setFrustumFar(10000);

        
      
        
        inputManager.setCursorVisible(true);
        mouseInput.setCursorVisible(true);
        org.lwjgl.input.Mouse.setGrabbed(false);
         //logic = new GameLogic("Models/castle02c00/castle02c00.j3o", bas);
        //running = true;
        bas = new BulletAppState();
        bas.setThreadingType(BulletAppState.ThreadingType.PARALLEL);
        stateManager.attach(bas);
        //flyCam.setEnabled(true);
        logic = new GameLogic("Models/castle02c00/castle02c00.j3o", bas);
        //inputManager.setCursorVisible(false);
        running = true;
        
    }
BulletAppState bas;


    
    


    GameLogic logic;
    @Override
    public void simpleUpdate(float tpf) {
        if (running) logic.update(tpf);
    }

    /** 
     * used for debuging 
     * @param str is called from place in code where you want to check something 
     */
    public void debug(String str) {
        sysout.setText(str);
    }

    public BitmapFont getGuiFont() {
        return guiFont;
    }

    public AppSettings getSettings() {
        return settings;
    }
    

    
}
