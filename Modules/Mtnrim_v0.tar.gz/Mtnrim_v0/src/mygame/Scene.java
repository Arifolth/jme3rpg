/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package mygame;

import com.jme3.bullet.collision.shapes.CollisionShape;
import com.jme3.bullet.control.RigidBodyControl;
import com.jme3.bullet.util.CollisionShapeFactory;
import com.jme3.light.DirectionalLight;
import com.jme3.math.Vector3f;
import com.jme3.renderer.queue.RenderQueue.ShadowMode;
import com.jme3.scene.Node;
import com.jme3.scene.Spatial;

/**
 *
 * @author filipe
 */
public class Scene extends GameEntity {
    public Node node;
    public Spatial spatial;
    public Scene(GameLogic gl, String fname) {
        super(gl);
        
        //set the name of the node
        type = TYPE.Other;
        setName("Map");

        //load a scene from the assets and attach it to this node
        spatial = Main.get().getAssetManager().loadModel(fname);
        node= (Node)spatial;
        
        this.attachChild(node);
                
        //add a sun
        DirectionalLight sun = new DirectionalLight();
        sun.setDirection(new Vector3f(-0.1f, -0.7f, -1.0f));
        this.addLight(sun);
        
  
        
        //set shadows
        this.setShadowMode(ShadowMode.CastAndReceive);
        
        //scale the level
        spatial.setLocalScale(20f);
        
        // add a physics control, it will generate a MeshCollisionShape based on the gameLevel
       
        CollisionShape sceneShape =
                CollisionShapeFactory.createMeshShape(spatial);


        RigidBodyControl phys = new RigidBodyControl(sceneShape, 0f);
        spatial.addControl(phys);
        
        birth();
    }
    
}
