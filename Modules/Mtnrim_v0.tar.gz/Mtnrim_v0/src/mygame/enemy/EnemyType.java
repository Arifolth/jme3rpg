package mygame.enemy;

/**
 *
 * @author filipe
 */
public enum EnemyType {
    SKELETON,
    FROG,
    IMP;
}
