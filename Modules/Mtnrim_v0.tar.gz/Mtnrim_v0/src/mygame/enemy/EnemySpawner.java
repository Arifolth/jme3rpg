package mygame.enemy;

import com.jme3.collision.CollisionResult;
import com.jme3.collision.CollisionResults;
import com.jme3.math.FastMath;
import com.jme3.math.Ray;
import com.jme3.math.Vector2f;
import com.jme3.math.Vector3f;
import mygame.GameEntity;
import mygame.GameLogic;
import mygame.Terrain;

/**
 *
 * @author scott
 */
public class EnemySpawner extends GameEntity {
    private static float INTERVAL = 2f;
    
    private int maxEnemiesAtOnce;
    private float checkInterval;
    private EnemyType enemyType;
    
    public EnemySpawner(GameLogic game, int maxAtOnce, EnemyType enemyType) {
        super(game);
        
        this.type = GameEntity.TYPE.Other;
        this.maxEnemiesAtOnce = maxAtOnce;
        this.checkInterval = INTERVAL;
        this.enemyType = enemyType;
        
        birth();
    }
    
    /*public void init() {
        // check for enemies:
        String typeName = enemyType.name().toLowerCase();
        
        for (int ix = 0; ix < 100; ix++) {
            String search = typeName + ix;
            Spatial item = game.getGameLevel().getChild(search);
            
            if (item != null) {
                Enemy e = new Enemy(game, enemyType, item);
            }
        }
    }*/
    
    @Override
    public void update(float tpf) {
        checkInterval -= tpf;
        
        if (checkInterval <= 0f) {
            int count = 0;
            for (Enemy e : game.getEnemies()) {
                if (e.getEnemyType() == enemyType) {
                    count++;
                }
            }
            float yloc = 5f;
            if (enemyType == EnemyType.IMP)
            {
                yloc = 10f;
            }
            
            if(count < maxEnemiesAtOnce) {
                //find random position in game level
                Terrain terrain = game.getTerrain();
                Vector3f center = game.getTerrain().getTerrain().getLocalTranslation();
                Vector3f min = center.subtract(terrain.getDimensions().divide(2f));
               Vector3f max = center.add(terrain.getDimensions().divide(2f));
               Vector3f loc = new Vector3f(FastMath.rand.nextFloat() * (300f) - 150f + - 512f,
                                            5000f,
                                            FastMath.rand.nextFloat() * (300f) - 150f + 512f);
               CollisionResults results = new CollisionResults();
        // 2. Aim the ray from cam loc to cam direction.
        Ray ray = new Ray(loc, new Vector3f(0, -1, 0));
        results = new CollisionResults();
   
        // 3. Collect intersections between Ray and Shootables in results list.
        terrain.getTerrain().collideWith(ray, results);
               CollisionResult hit = results.getClosestCollision();
       
               Vector3f loc2 = new Vector3f(hit.getContactPoint().x, hit.getContactPoint().y + 3f, hit.getContactPoint().z);
                //create new enemy and place at random position
                Enemy e = Enemy.createEnemy(game, loc2, enemyType);
            }
            
            checkInterval = INTERVAL;
        }
    }
}
