package mygame;


import mygame.weapon.Bullet;
import mygame.weapon.MagicEffect;
import mygame.enemy.Enemy;
import com.jme3.app.Application;
import com.jme3.asset.AssetManager;
import com.jme3.bullet.BulletAppState;
import com.jme3.bullet.PhysicsSpace;
import com.jme3.collision.CollisionResult;
import com.jme3.collision.CollisionResults;
import com.jme3.input.InputManager;
import com.jme3.input.KeyInput;
import com.jme3.input.MouseInput;
import com.jme3.input.controls.KeyTrigger;
import com.jme3.input.controls.MouseAxisTrigger;
import com.jme3.input.controls.MouseButtonTrigger;
import com.jme3.math.Ray;
import com.jme3.math.Vector3f;
import com.jme3.scene.Node;
import java.util.List;
import java.util.concurrent.CopyOnWriteArrayList;
import mygame.enemy.EnemySpawner;
import mygame.enemy.EnemyType;

/**
 *
 * @author scott
 */
public class GameLogic  {

    private Player player;
    private List<Enemy> enemies = new CopyOnWriteArrayList<Enemy>();
    private List<Bullet> bullets = new CopyOnWriteArrayList<Bullet>();
    private List<MagicEffect> effects = new CopyOnWriteArrayList<MagicEffect>();
    private List<GameEntity> other = new CopyOnWriteArrayList<GameEntity>();
    private String levelName;
    private Scene gameLevel;
    private HUD hud;
    private Main main = Main.get();
    private BulletAppState bulletAppState;
    Terrain terrain;
    //LiberGUI nifty;

    public GameLogic(String fname, BulletAppState bas) {
        levelName = fname;
        initialize(bas);
    }


    public void initialize(BulletAppState bas) {

        bulletAppState= bas;
        //setup physics state manager
        

        //initialize level/scene
        gameLevel = new Scene(this, levelName);
        terrain = new Terrain();
        getPhysicsSpace().add(terrain.init(Main.get()));

        //create the player with the starting player position at "playerPos" from the scene
        //Spatial startLoc = gameLevel.getChild("playerPos");
        CollisionResults results = new CollisionResults();
        // 2. Aim the ray from cam loc to cam direction.
        Vector3f start = new Vector3f(-512,5000f,512);
        Ray ray = new Ray(start, new Vector3f(0, -1, 0));
        results = new CollisionResults();

        // 3. Collect intersections between Ray and Shootables in results list.
        terrain.getTerrain().collideWith(ray, results);
        CollisionResult hit = results.getClosestCollision();

        Vector3f loc2 = new Vector3f(hit.getContactPoint().x, hit.getContactPoint().y + 3f, hit.getContactPoint().z);

        //start.mult(20f);
        player = new Player(this, loc2); //gameLevel.getChild("playerPos"));

        //setup hud
        hud = new HUD(this);
        main.getGuiNode().attachChild(hud);
        addOther(hud);

        //attach player and level to physics space
        gameLevel.node.setLocalTranslation(gameLevel.node.getLocalTranslation().add(new Vector3f (-10,0,0)));
        getPhysicsSpace().addAll(gameLevel);
        getPhysicsSpace().add(player.getPhysicsControl());

        // get enemies from spawn points:
        spawnEnemies();

        //setup keys:
        setupKeys();
        
        //nifty = new LiberGUI();
        //nifty.init();
        
    }

    public PhysicsSpace getPhysicsSpace() {
        return bulletAppState.getPhysicsSpace();
    }

    public void spawnEnemies() {
        EnemySpawner skeletonSpawner = new EnemySpawner(this, 10, EnemyType.SKELETON);
        EnemySpawner impSpawner = new EnemySpawner(this, 10, EnemyType.IMP);
        EnemySpawner frogSpawner = new EnemySpawner(this, 10, EnemyType.FROG);
    }

    public void setupKeys() {
        InputManager inputManager = Main.get().getInputManager();
        inputManager.addMapping("Lefts", new KeyTrigger(KeyInput.KEY_A));
        inputManager.addMapping("Rights", new KeyTrigger(KeyInput.KEY_D));
        inputManager.addMapping("Ups", new KeyTrigger(KeyInput.KEY_W));
        inputManager.addMapping("Downs", new KeyTrigger(KeyInput.KEY_S));
        inputManager.addMapping("Space", new KeyTrigger(KeyInput.KEY_SPACE));
        inputManager.addMapping("Fire", new KeyTrigger(KeyInput.KEY_F),
                new MouseButtonTrigger(MouseInput.BUTTON_LEFT));
        inputManager.addMapping("WeaponNext", new MouseAxisTrigger(MouseInput.AXIS_WHEEL, true),
                new KeyTrigger(KeyInput.KEY_LBRACKET));
        inputManager.addMapping("WeaponPrev", new MouseAxisTrigger(MouseInput.AXIS_WHEEL, false),
                new KeyTrigger(KeyInput.KEY_RBRACKET));

        inputManager.addListener(player, "Lefts", "Rights", "Ups", "Downs");
        inputManager.addListener(player, "Space", "Fire", "WeaponNext", "WeaponPrev");
    }

    
    public void update(float tpf) {
        player.update(tpf);

        for (MagicEffect m : effects) {
            m.update(tpf);
        }

        for (Enemy e : enemies) {
            e.update(tpf);
        }

        for (GameEntity o : other) {
            o.update(tpf);
        }
        //hud.update(tpf);
    }

    public void remove(GameEntity entity) {
        switch (entity.type) {
            case Player:
                removePlayer();
                break;
            case Enemy:
                removeEnemy((Enemy) entity);
                break;
            case Bullet:
                removeBullet((Bullet) entity);
                break;
            case MagicEffect:
                removeEffect((MagicEffect) entity);
                break;
            default:
                ;
        }
    }

    public void removePlayer() {
    }

    public void removeEnemy(Enemy enem) {
        enemies.remove(enem);
    }

    public void removeBullet(Bullet bull) {
        bullets.remove(bull);
    }

    public void removeEffect(MagicEffect eff) {
        effects.remove(eff);
    }

    public void add(GameEntity entity) {
        switch (entity.type) {
            case Player:
                break; // nothing here
            case Enemy:
                addEnemy((Enemy) entity);
                break;
            case Bullet:
                addBullet((Bullet) entity);
                break;
            case MagicEffect:
                addEffect((MagicEffect) entity);
                break;
            case Other:
                addOther((GameEntity) entity);
                break;
            default:
                ;
        }
    }

    public void addEnemy(Enemy enem) {
        enemies.add(enem);
    }

    public void addBullet(Bullet bull) {
        bullets.add(bull);
    }

    public void addEffect(MagicEffect eff) {
        effects.add(eff);
    }

    public void addOther(GameEntity ent) {
        other.add(ent);
    }

    public Scene getGameLevel() {
        return gameLevel; //gameLevel;
    }

    public Terrain getTerrain() {
        return terrain;
    }

    public Player getPlayer() {
        return player;
    }

    public HUD getHud() {
        return hud;
    }

    public Node getRootNode() {
        return main.getRootNode();
    }

    public AssetManager getAssetManager() {
        return main.getAssetManager();
    }

    public List<Enemy> getEnemies() {
        return enemies;
    }
    // BORN: ------------------
    // LIFE: ------------------
    // IMPACT: ----------------
    // DAMAGE: ----------------
    // DEATH: -----------------
}
